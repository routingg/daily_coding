import paho.mqtt.client as mqtt
import time
import json
import random
import datetime
import os  

# --- 설정 ---
BROKER = "localhost"
PORT = 1883
FLEET_ID = "lab"
DRONE_IDS = ["라이더1", "라이더2", "라이더3", "라이더4"]
PUBLISH_INTERVAL_SEC = 1

# 로그 저장 디렉토리
# 로그 저장 디렉토리
LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)  

# --- MQTT 클라이언트 생성 ---
def create_client():
    client = mqtt.Client(protocol=mqtt.MQTTv5)
    try:
        client.connect(BROKER, PORT, 60)
        print(f"✅ Publisher connected to MQTT Broker at {BROKER}:{PORT}")
        return client
    except Exception as e:
        print(f"❌ Failed to connect to broker: {e}")
        return None

# --- 데이터 발행 ---
# --- JSONL 로그 파일 경로 ---
jsonl_filename = os.path.join(LOG_DIR, f"telemetry_{datetime.datetime.now().strftime('%Y%m%d')}.jsonl")

# --- 데이터 발행 ---
def publish_telemetry(client):
    print(f"🚀 Starting data publishing for {len(DRONE_IDS)} delivery drones...")
    counter = 0

    while True:
        try:
            current_time_ts = time.time()
            timestamp_str = datetime.datetime.fromtimestamp(current_time_ts).strftime("%Y%m%d_%H%M%S")

            for drone_id in DRONE_IDS:
                topic = f"drone/{FLEET_ID}/{drone_id}/telemetry/gps"
                msg = {
            "id": drone_id,
            "lat": round(33.4569 + random.uniform(-0.005, 0.005), 6),  # 아라동 위도
            "lon": round(126.5543 + random.uniform(-0.005, 0.005), 6), # 아라동 경도
            "alt": round(random.uniform(50, 150), 2),
            "bat": random.randint(80, 100),
            "spd": round(random.uniform(2, 7), 1),
            "hdg": random.randint(0, 359),
            "fix": True,
            "ts": current_time_ts
    }

                # --- 드론별 시뮬레이션 ---
                if drone_id == "라이더1":
                    if counter % 50 == 0:
                        msg["bat"] = 105
                        print(f"🚨 Anomaly Test: {drone_id} bat={msg['bat']}%")

                elif drone_id == "라이더3":
                    topic = f"drone/{FLEET_ID}/{drone_id}/status/delay"
                    msg = {
                        "id": drone_id,
                        "delay_sec": round(random.uniform(5, 15), 1),
                        "timestamp": datetime.datetime.fromtimestamp(current_time_ts).isoformat()
                    }

                    if counter % 10 != 0:
                        continue  # 10에 한번 발행

                elif drone_id == "라이더4":
                    # 고의적 깨진 JSON → 저장 안 함, 로그만 출력
                    payload = '{"id": "라이더4", "lat": 37.5, "lon": 127.0, "alt": '
                    print(f"💥 System Error: {drone_id} sent intentionally broken JSON.")

                    # 깨진 JSON 따로 저장 
                    error_file = os.path.join(LOG_DIR, f"corrupted_{drone_id}_{timestamp_str}.json")
                    with open(error_file, "w", encoding="utf-8") as f:
                        f.write(payload)

                    continue  # MQTT 전송 및 jsonl 저장하지 않음

                # --- 직렬화 및 MQTT 발행 ---
                payload = json.dumps(msg)
                client.publish(topic, payload, qos=0)

                # --- JSONL 저장 (append mode) ---
                with open(jsonl_filename, "a", encoding="utf-8") as f:
                    f.write(payload + "\n")

                # --- 로그 출력 ---
                print(f"📤 Published to {topic}: ID={drone_id}, Bat={msg.get('bat', 'N/A')}%")

            time.sleep(PUBLISH_INTERVAL_SEC)
            counter += 1

        except KeyboardInterrupt:
            print("\n⏹ Data publishing stopped by user.")
            break
        except Exception as e:
            print(f"⚠️ Error during publishing: {e}")
            time.sleep(5)


# --- 메인 실행 ---
if __name__ == "__main__":
    client = create_client()
    if client:
        try:
            client.loop_start()
            publish_telemetry(client)
        finally:
            client.loop_stop()
            client.disconnect()
            print("🔌 Publisher disconnected.")
