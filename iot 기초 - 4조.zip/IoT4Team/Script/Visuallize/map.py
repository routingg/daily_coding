import pandas as pd
import folium
from folium.plugins import AntPath

try:
    ride1 = pd.read_csv('ride1.csv', nrows=30)
    ride2 = pd.read_csv('ride2.csv', nrows=30)
    #ride3 = pd.read_csv('ride3.csv', nrows=30)
    #ride4 = pd.read_csv('ride4.csv', nrows=30)

    all_rides = pd.concat([ride1, ride2])
    map_center = [all_rides['lat'].mean(), all_rides['lon'].mean()]
    m = folium.Map(location=map_center, zoom_start=14, tiles='OpenStreetMap')

    colors = {
    '라이더1': 'blue', 
    '라이더2': 'red',
    #'라이더3': 'purple', 
    #'라이더4': 'green'
    }

    for rider_id, group in all_rides.groupby('id'):
        path_points = group[['lat', 'lon']].values.tolist()
    
        if path_points:
            AntPath(
                locations=path_points,
                delay=2000,
                color=colors.get(rider_id, 'black'),
                weight=5,
                dash_array=[10, 20],
                pulse_color='gray',
                tooltip=f'{rider_id} 경로'
            ).add_to(m)

            start_location = path_points[0]

            folium.Marker(
                location=start_location,
                popup=f'<b>{rider_id} 시작</b>',
                tooltip=f'{rider_id} Start',
                icon=folium.Icon(color=colors.get(rider_id, 'gray'), icon='play', prefix='fa')
            ).add_to(m)

            folium.CircleMarker(
                location=start_location,
                radius=8, 
                color=colors.get(rider_id, 'black'),
                fill=True,
                fill_opacity=0.7
            ).add_to(m)


            end_location = path_points[-1]
            
            folium.Marker(
                location=end_location,
                popup=f'<b>{rider_id} 종료</b>',
                tooltip=f'{rider_id} End',
                icon=folium.Icon(color=colors.get(rider_id, 'gray'), icon='stop', prefix='fa')
            ).add_to(m)

            folium.CircleMarker(
                location=end_location,
                radius=8, 
                color='red', 
                fill=True,
                fill_color='red',
                fill_opacity=0.7
            ).add_to(m)

    # 8. HTML 파일로 저장
    output_filename = 'map.html'
    m.save(output_filename)
    
    print(f"'{output_filename}' 파일이 저장되었습니다.")

except FileNotFoundError:
    print("파일을 찾을 수 없습니다.")
except Exception as e:
    print(f"지도 생성 중 오류가 발생했습니다: {e}")