import pandas as pd
import matplotlib.pyplot as plt
import json

try:
    # --- 1. 데이터 로딩 ---
    ride1_df = pd.read_csv('ride1.csv')
    ride2_df = pd.read_csv('ride2.csv')
    ride3_df = pd.read_csv('ride3.csv')
    ride4_df = pd.read_csv('ride4.csv')

    for col in ['spd', 'alt', 'bat']:
        ride3_df[col] = ride3_df[col].fillna(0)

    all_rides_df = pd.concat([
        ride1_df.assign(rider_id='rider1'),
        ride2_df.assign(rider_id='rider2'),
        ride3_df.assign(rider_id='rider3'),
        ride4_df.assign(rider_id='rider4')
    ], ignore_index=True)


    all_rides_df['time_iso'] = pd.to_datetime(all_rides_df['time_iso'])

    # Speed 그래프
    plt.figure(figsize=(12, 6))
    for rider in all_rides_df['rider_id'].unique():
        rider_data = all_rides_df[all_rides_df['rider_id'] == rider]
        plt.plot(rider_data['time_iso'], rider_data['spd'], label=rider)
    plt.title('Speed')
    plt.xlabel('Time')
    plt.ylabel('Speed (m/s)')
    plt.legend()
    plt.grid(True)
    plt.savefig('speed.png')
    plt.close()

    # Altitude 그래프
    plt.figure(figsize=(12, 6))
    for rider in all_rides_df['rider_id'].unique():
        rider_data = all_rides_df[all_rides_df['rider_id'] == rider]
        plt.plot(rider_data['time_iso'], rider_data['alt'], label=rider)
    plt.title('Altitude')
    plt.xlabel('Time')
    plt.ylabel('Altitude (m)')
    plt.legend()
    plt.grid(True)
    plt.savefig('altitude.png')
    plt.close()

    # Battery 그래프
    plt.figure(figsize=(12, 6))
    for rider in all_rides_df['rider_id'].unique():
        rider_data = all_rides_df[all_rides_df['rider_id'] == rider]
        plt.plot(rider_data['time_iso'], rider_data['bat'], label=rider)
    plt.title('Battery')
    plt.xlabel('Time')
    plt.ylabel('Battery (%)')
    plt.legend()
    plt.grid(True)
    plt.savefig('battery.png')
    plt.close()

except FileNotFoundError:
    print("오류: CSV 파일들이 코드와 같은 폴더에 있는지 확인해주세요.")
except Exception as e:
    print(f"오류가 발생했습니다: {e}")