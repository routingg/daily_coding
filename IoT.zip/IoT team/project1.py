import os
import csv
import json
import time
import logging
from datetime import datetime, timedelta
import paho.mqtt.client as mqtt

# --- 설정 및 전역 변수 ---
FLEET = os.getenv("FLEET", "lab")
BASE_DIR = r"C:\IoT team\jeju\Aradong"
ROTATE_EVERY_SEC = 60 # 1분단위 회전
CSV_ENCODING = "utf-8-sig" # 한글깨짐방지 인코딩 
HEADER = ["time_iso", "time_unix", "id", "lat", "lon", "alt", "bat", "spd", "hdg", "fix", "topic", "raw_json"] # 표준 컬럼 

# 문제: 드론의 데이터를 하나의 파일에 저장 시 관리, 서칭이 힘들다는 단점 존재
# 드론 ID별 파일 핸들, CSV 라이터, 마지막 회전 시간을 관리하는 딕셔너리 생성하여 객체별 관리
# 드론 아이티를 키로하여 저장하므로 다수 드론을 동시에 관리 가능
FILE_HANDLES = {}
WRITERS = {}
LAST_ROTATED = {}
# 데이터 검증 범위 
LAT_RANGE = (-90.0, 90.0)
LON_RANGE = (-180.0, 180.0)
BAT_RANGE = (0.0, 100.0)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

# --- 헬퍼 함수: 경로 및 시간 처리 ---

def to_iso(ts):
    """UNIX epoch 시간을 KST(UTC+9)의 ISO8601 형식으로 변환"""
    # UTC + 9시간 (KST) 적용
    dt_kst = datetime.utcfromtimestamp(ts) + timedelta(hours=9) 
    return dt_kst.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+09:00"

def get_file_path(drone_id, timestamp):
    """드론 ID와 시간을 기반으로 '드론ID별/연/월/일' 폴더 구조 및 파일명 생성 """
    dt_kst = datetime.utcfromtimestamp(timestamp) + timedelta(hours=9)
    # 폴더 구조: BASE_DIR/FLEET/DRONE_ID/YYYY/MM/DD/
    date_path = dt_kst.strftime("%Y/%m/%d")
    # 파일명 규칙: telemetry_YYYYMMDD_HHMM.csv
    filename = dt_kst.strftime("telemetry_%Y%m%d_%H%M.csv") 
    
    dir_path = os.path.join(BASE_DIR, FLEET, drone_id, date_path)
    os.makedirs(dir_path, exist_ok=True)
    
    return os.path.join(dir_path, filename)

# --- 파일 I/O 및 회전 로직 ---

def ensure_header(path, writer):
    """파일이 새로 생성될 때만 헤더를 한 번 작성하여 이중 헤더 방지"""
    exists = os.path.exists(path) and os.path.getsize(path) > 0
    if not exists:
        writer.writerow(HEADER)
        logging.info(f"Header written to: {path}")

def rotate_and_open_file(drone_id, current_ts):
    """파일 회전을 수행하고 새 파일 핸들 반환"""
    global FILE_HANDLES, WRITERS, LAST_ROTATED
    
    if FILE_HANDLES.get(drone_id):
        FILE_HANDLES[drone_id].close() # 기존 파일 닫기\
        
    new_path = get_file_path(drone_id, current_ts)

    try:
        # 'a' (append) 모드, Windows 호환(newline), Excel 호환(encoding) 
        new_file = open(new_path, "a", newline="", encoding=CSV_ENCODING)
        new_writer = csv.writer(new_file)
        
        ensure_header(new_path, new_writer)
        
        # 상태 업데이트
        FILE_HANDLES[drone_id] = new_file
        WRITERS[drone_id] = new_writer
        LAST_ROTATED[drone_id] = current_ts
        logging.info(f"File rotated and opened for {drone_id}: {new_path}")
        
    except Exception as e:
        logging.error(f"Error opening/rotating file for {drone_id}: {e}")
        FILE_HANDLES[drone_id] = None

def normalize_data(obj, topic, raw_payload):
    """수신 데이터 정규화 및 CSV 행으로 변환"""
    #토픽에서 드론아이디 추출하고, ISO타임 생성 및 CSV 행 생성
    ts = float(obj.get("ts", time.time())) 
    time_iso = to_iso(ts)
    
    # 토픽에서 드론 ID 추출: 'drone/fleet/id/...' 
    topic_parts = topic.split('/')
    drone_id = topic_parts[2] if len(topic_parts) >= 3 and topic_parts[0] == 'drone' else str(obj.get("id", "unknown-drone"))

    data = {
        "time_iso": time_iso, "time_unix": ts, "id": str(obj.get("id", drone_id)),
        "lat": obj.get("lat"), "lon": obj.get("lon"), "alt": obj.get("alt"),
        "bat": obj.get("bat"), "spd": obj.get("spd"), "hdg": obj.get("hdg"),
        "fix": obj.get("fix"), "topic": topic, "raw_json": raw_payload
    }

    # HEADER 순서에 맞게 CSV 행 데이터 생성
    row_data = [data[k] for k in HEADER[:-1]] + [data["raw_json"]]
    return data, drone_id, row_data

# --- MQTT 콜백 함수 ---

def on_connect(client, userdata, flags, rc, pr=None):
    """연결 성공 시 다중 드론 토픽 구독 설정 \\"""
    if rc == 0:
        logging.info("✅ Connected to MQTT Broker!")
        # 와일드카드 구독: 동일한 브로커에 있는 여러드론의 메세지를 한 클라이언트로 수신
        client.subscribe(f"drone/{FLEET}/+/telemetry/#", qos=0)
        client.subscribe(f"drone/{FLEET}/+/status/#", qos=0)
    else:
        logging.error(f"❌ Failed to connect. Code: {rc}")

def on_message(client, userdata, msg):
    """메시지 수신 시 처리: 파싱 -> 검증 -> 회전 체크 -> 저장 """
    current_ts = time.time()
    
    try:
        raw_payload = msg.payload.decode("utf-8", "ignore")
        obj = json.loads(raw_payload)
        
        data, drone_id, row_data = normalize_data(obj, msg.topic, raw_payload)
            
        # 2. 파일 회전 및 핸들 확보
        if drone_id not in FILE_HANDLES or (current_ts - LAST_ROTATED.get(drone_id, 0) > ROTATE_EVERY_SEC):
            rotate_and_open_file(drone_id, current_ts)
        
        writer = WRITERS.get(drone_id)
        file_handle = FILE_HANDLES.get(drone_id)

        if writer:
            # 3. CSV 저장 및 즉시 디스크 쓰기
            writer.writerow(row_data)
            file_handle.flush() # 데이터 손실 방지를 위해 즉시 flush 
        
    except json.JSONDecodeError:
        logging.error(f"[{msg.topic}] JSON Decode Error: {raw_payload[:120]}")
    except Exception as e:
        logging.error(f"An error occurred in on_message: {e} on topic {msg.topic}")

def main():
    try:
        client = mqtt.Client(protocol=mqtt.MQTTv5, transport="tcp",
                             callback_api_version=mqtt.CallbackAPIVersion.V5)
    except Exception:
        client = mqtt.Client(protocol=mqtt.MQTTv5, transport="tcp")
        
    client.on_connect = on_connect
    client.on_message = on_message
    
    host = os.getenv("MQTT_HOST", "localhost")
    port = int(os.getenv("MQTT_PORT", "1883"))
    
    logging.info(f"Connecting to MQTT broker at {host}:{port}")
    client.connect(host, port, 60)

    logging.info("Subscriber started. Press Ctrl+C to stop.")
    client.loop_forever()
    
if __name__ == "__main__":
    # 실행 전 로그 디렉토리 생성
    os.makedirs(BASE_DIR, exist_ok=True)
    try:
        main()
    except KeyboardInterrupt:
        logging.info("⏹ Subscriber stopped by user.")
    finally:
        # 프로그램 종료 시 모든 파일 핸들 닫기
        for handle in FILE_HANDLES.values():
            if handle:
                handle.close()
        logging.info("All file handles closed.")
